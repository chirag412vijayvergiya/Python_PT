f=open("child.txt", 'r')
# data=f.read(12)
# print(data)
# f.close()