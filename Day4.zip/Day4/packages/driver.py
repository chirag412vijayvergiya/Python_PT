# import  chirag 
# chirag.add (10, 20)
# chirag.sub (22,11)
# print(chirag.n1)

# import  chirag  as c
# c.add (10, 20)
# c.sub (22,11)
# print(c.n1)

# from chirag import add, sub, n1 
# add (10, 20)
# sub (22,11)
# print(n1)

# from chirag import *
# add (10, 20)
# sub (22,11)
# print(n1)


from arithmatic.chirag import *
add (10, 20)
sub (22,11)
print(n1)


